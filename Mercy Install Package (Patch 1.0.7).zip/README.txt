-----------------------------------------------------
     __  __   ______   _____    _____  __     __
    |  \/  | |  ____| |  __ \  |  ___\ \ \   / /
    | \  / | | |__    | |__) | | |      \ \_/ /
    | |\/| | |  __|   |  _  /  | |       \   /
    | |  | | | |____  | | \ \  | |____    | |
    |_|  |_| |______| |_|  \_\ |_____/    |_|

-----------------------------------------------------

Description:
-------------
A text based medieval fantasy adventure game programmed
in C by Cole Bishop


Installation:
-------------

Method 1.
Place the extracted Mercy Install Package folder wherever 
in your file system that you prefer and launch Mercy 
directly from the application file itself. Save files will
be created and stored in the same folder as the Application
file.

Method 2 (Recommended).
Place the Mercy install package somewhere in the backend
of your file system and make a shortcut to the executable
in whatever location you keep application shortcuts. This
is recommended to limit clutter on the users end as save
files will be created and stored in the same folder as
the Mercy executable.


Usage:
-------------
The functionality of Mercy revolves around simple menus with
numbered options. The numbered options may consist of possible
actions you can take or other submenus you can enter with the
last option usually being "back" to take you to the previous
menu. You will always be able to select the option that you want 
by entering the corresponding number. For explanations on specific
game mechanics such as combat and crafting there is a built in 
handbook with labeled sections containing tips and explanations
regarding aspects of the game.


Final Notes:
-------------
This project is my attempt at adapting a full-fledged adventure
game with quest lines, combat, progression systems, and activities
into a text based program running in terminal. Have fun!

